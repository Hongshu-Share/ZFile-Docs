# 反馈交流

关于项目中的一些问题，欢迎进入交流群一起讨论，<a target="_blank" href="//shang.qq.com/wpa/qunwpa?idkey=8082ee9c113986552dff109b09b33a80d849da1e03cd8bef3068e2647198950e"><img border="0" src="//pub.idqqimg.com/wpa/images/group.png" alt="ZFile 交流反馈群" title="ZFile 交流反馈群"></a>

<img src="http://cdn.jun6.net/2020/02/09/e49f2cef5cdae.png" width="30%">